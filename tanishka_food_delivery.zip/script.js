
let cart = [];

function addToCart(item, price) {
  cart.push({ item, price });
  updateCart();
}

function updateCart() {
  const cartList = document.getElementById('cart-items');
  const totalDisplay = document.getElementById('total');
  cartList.innerHTML = '';
  let total = 0;
  cart.forEach(product => {
    const li = document.createElement('li');
    li.textContent = `${product.item} - ₹${product.price}`;
    cartList.appendChild(li);
    total += product.price;
  });
  totalDisplay.textContent = `Total: ₹${total}`;
}
